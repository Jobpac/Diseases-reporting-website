<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';

// Fetch reports from the database
$stmt = $pdo->query("SELECT posts.*, users.first_name, users.second_name FROM posts JOIN users ON posts.user_id = users.id ORDER BY created_at DESC");
$reports = $stmt->fetchAll();
?>

<h2>Reported Diseases</h2>
<?php if ($reports): ?>
    <?php foreach ($reports as $report): ?>
        <div class="report">
            <h3><?php echo htmlspecialchars($report['description']); ?></h3>
            <p>Posted by: <?php echo htmlspecialchars($report['first_name'] . ' ' . $report['second_name']); ?></p>
            <p>Location: <?php echo htmlspecialchars($report['location']); ?></p>
            <p>Time: <?php echo htmlspecialchars($report['created_at']); ?></p>
            <?php if ($report['media']): ?>
                <img src="uploads/<?php echo htmlspecialchars($report['media']); ?>" alt="Report Media" style="max-width: 100%;">
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <p>No reports available.</p>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>