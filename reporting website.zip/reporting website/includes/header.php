<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Disease Reporting Website</title>
</head>
<body>
    <header>
        <h1>Disease Reporting Website</h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="post_report.php">Post a Report</a>
            <a href="register.php">Register</a>
            <a href="login.php">Login</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>
    <main>