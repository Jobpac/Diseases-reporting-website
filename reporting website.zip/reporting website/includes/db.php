<?php
$host = 'localhost';
$db = 'disease_reporting'; // Change this to your database name
$user = 'root'; // Change this if you have a different username
$pass = ''; // Change this if you have a password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>