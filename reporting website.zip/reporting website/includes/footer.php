</main>
    <footer>
        <p>&copy; 2024 Disease Reporting Website</p>
    </footer>
</body>
</html>