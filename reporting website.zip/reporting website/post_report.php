<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $description = $_POST['description'];
    $location = $_POST['location'];
    $media = '';

    if (isset($_FILES['media']) && $_FILES['media']['error'] == 0) {
        $media = basename($_FILES['media']['name']);
        move_uploaded_file($_FILES['media']['tmp_name'], "uploads/$media");
    }

    $stmt = $pdo->prepare("INSERT INTO posts (user_id, description, media, location) VALUES (?, ?, ?, ?)");
    $stmt->execute([$_SESSION['user_id'], $description, $media, $location]);
    header("Location: index.php");
    exit();
}
?>

<h2>Post a Report</h2>
<form method="POST" enctype="multipart/form-data">
    <textarea name="description" placeholder="Description" required></textarea>
    <input type="text" name="location" placeholder="Location" required>
    <input type="file" name="media">
    <button type="submit">Submit Report</button>
</form>

<?php include 'includes/footer.php'; ?>