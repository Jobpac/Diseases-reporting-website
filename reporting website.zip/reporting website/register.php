<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = $_POST['first_name'];
    $second_name = $_POST['second_name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO users (first_name, second_name, email, password) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$first_name, $second_name, $email, $password])) {
        echo "Registration successful!";
        header("Location: login.php");
        exit();
    } else {
        echo "Registration failed.";
    }
}
?>

<h2>Register</h2>
<form method="POST">
    <input type="text" name="first_name" placeholder="First Name" required>
    <input type="text" name="second_name" placeholder="Second Name" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Register</button>
</form>

<?php include 'includes/footer.php'; ?>