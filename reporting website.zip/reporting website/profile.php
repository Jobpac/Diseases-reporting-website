<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';

if (!isset($_SESSION['user_id']))) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = $_POST['first_name'];
    $second_name = $_POST['second_name'];
    $email = $_POST['email'];

    $stmt = $pdo->prepare("UPDATE users SET first_name = ?, second_name = ?, email = ? WHERE id = ?");
    $stmt->execute([$first_name, $second_name, $email, $user_id]);
    echo "Profile updated successfully!";
}

?>

<h2>User Profile</h2>
<form method="POST">
    <input type="text" name="first_name" value="<?php echo htmlspecialchars($user['first_name']); ?>" required>
    <input type="text" name="second_name" value="<?php echo htmlspecialchars($user['second_name']); ?>" required>
    <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
    <button type="submit">Update Profile</button>
</form>

<?php include 'includes/footer.php'; ?>